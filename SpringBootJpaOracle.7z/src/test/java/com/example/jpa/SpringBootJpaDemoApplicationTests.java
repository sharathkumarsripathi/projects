package com.example.jpa;

class SpringBootJpaDemoApplicationTests {

	void contextLoads() {
	}

}
